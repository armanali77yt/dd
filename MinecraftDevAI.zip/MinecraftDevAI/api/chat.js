// Yeh code Vercel ke liye ek serverless function hai
// Ismein Gemini API ka istemaal hoga
import { GoogleGenAI } from '@google/genai';

// API Key Environment Variable se uthayenge
const ai = new GoogleGenAI(process.env.GEMINI_API_KEY);

export default async function handler(request, response) {
  try {
    // User ka sawal request body se lenge
    const { prompt } = await request.body;

    // AI model aur instruction define karenge
    const model = ai.models.getGenerativeModel({ model: 'gemini-2.5-flash' });
    
    // Yahan aap apne Minecraft-specific instructions daal sakte hain
    const systemInstruction = "You are a professional Minecraft Server Developer AI. Respond only with valid YAML or Java/JS code/configuration when asked for code, and always keep responses brief and to the point. Your goal is to modify config files or write plugin code based on the user's request.";

    const result = await model.generateContent({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        config: {
            systemInstruction: systemInstruction,
            temperature: 0.5,
        },
    });

    response.status(200).json({
      success: true,
      answer: result.text.trim(),
    });
  } catch (error) {
    console.error(error);
    response.status(500).json({ success: false, error: 'AI processing failed.' });
  }
}
